<?php
include_once "library/inc.seslogin.php";
include_once "library/inc.connection.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Turn On The Lamp</title>
</head>

<body>
<h3>LED pin 16 BIRU</h3>
<input type="button" onClick="led(16,'ON')" value="ON">
<input type="button" onClick="led(16,'OFF')" value="OFF">
<br><br>
<h3>LED pin 4 PUTIH</h3>
<input type="button" onClick="led(4,'ON')" value="ON">
<input type="button" onClick="led(4,'OFF')" value="OFF">
<h3>LED pin 12 MERAH</h3>
<input type="button" onClick="led(12,'ON')" value="ON">
<input type="button" onClick="led(12,'OFF')" value="OFF">
</body>
</html>